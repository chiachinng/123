document.write("HELLO我是水含甜心 ")
